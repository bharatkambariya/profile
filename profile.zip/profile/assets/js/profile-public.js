$ = jQuery;
var ajaxurl = myAjax.ajaxurl;
$( document ).ready(function() {
		$( "#pf-search-form" ).on(
			"submit",
			function (event) {
				event.preventDefault();
				$(this).parents('.profile-main').find('.current-page').val(1);
				pf_profile_ajax();
			}
		);

		//Ajax function for profile
		function pf_profile_ajax(){
			var formData = $( ".pf-search-form" ).serialize();
			$.ajax(
				{
					type: 'POST',
					url: ajaxurl,
					data: {
						action: 'profile_ajax_function',
						formData: formData,
						skills: $('.skills-multiple').val(),
						education: $('.education-multiple').val(),
					},
					success: function(response) {
						if(response.success){
							$( '.detail-form tbody tr:not(:first-child)' ).remove();
							$( '.pf-pagination' ).empty();
							$( '.detail-form .data-table tbody' ).append( response.data.profile_data );
							$( '.pf-pagination' ).append( response.data.pagination );
						}
					}
				}
			);
		}

	//ASC DESC order for Profile name
	$(".data-table .headerSortdown").click(function(){
		if($(".pf-search-form .shorting").hasClass("asc")){
			$(this).removeClass('asc').addClass("desc");
			$(".pf-search-form .shorting").removeClass("asc").addClass("desc");
			$(".pf-search-form .shorting").val("desc");
		} else {
			$(this).removeClass('desc').addClass("asc");
			$(".pf-search-form .shorting").removeClass("desc").addClass("asc");
			$(".pf-search-form .shorting").val("asc");
		}
		pf_profile_ajax();

	});
	$(".skills.ratings .clear-rating").click(function(){
		$(".stars .fa-star").removeClass("active");
		$(".skills.ratings .pf-ratings").val("");
	});
	//Profile Pagination
	jQuery('.pf-pagination').on( 'click', 'a', function( event ) {
		event.preventDefault();
		var current_href = this.href;
		var currentNumbers = current_href.replace(/[^0-9]/g, ' ').trim().split(/\s+/);
		currentNumbers = parseInt(currentNumbers[currentNumbers.length - 1], 10);
		$(this).parents('.profile-main').find('.current-page').val(currentNumbers);
		pf_profile_ajax();
	});
	//Range Slider JS
	$( "#slider-range" ).slider({
		range: true,
		min: 1,
		max: 100,
		values: [ 1, 100 ],
		slide: function( event, ui ) {
			$( "#amount" ).val(   ui.values[ 0 ] + " - " + ui.values[ 1 ] );
			$("#min-value").val(ui.values[ 0 ]);
			$("#max-value").val(ui.values[ 1 ]);
		}
	});
	$( "#amount" ).val(   $( "#slider-range" ).slider( "values", 0 ) + " - " + $( "#slider-range" ).slider( "values", 1 ) );

	//Multi Select drop-down JS
	$('.skills-multiple').select2();
	$('.education-multiple').select2();

	// For star rating
	const stars = document.querySelectorAll( ".stars i" );
	stars.forEach(
		(star, index1) => {
			star.addEventListener(
				"click",
				() => {
					document.getElementById( "pf-ratings" ).value = index1 + 1;
					stars.forEach(
						(star, index2) => {
							index1 >= index2 ? star.classList.add( "active" ) : star.classList.remove( "active" );
						}
					);
				}
			);
		}
	);

});
