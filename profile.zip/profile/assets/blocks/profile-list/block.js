(function (wpI18n, wpBlocks, wpElement, wpEditor, wpComponents) {
    const { __ } = wpI18n;
    const { Component, Fragment } = wpElement;
    const { registerBlockType } = wpBlocks;
    const { InspectorControls, ServerSideRender } = wpEditor;
    const { PanelBody, RangeControl } = wpComponents;
    
    class ProfileList extends Component {
        render() {
            const { attributes: { itemToFetch }, setAttributes } = this.props;
            return (
                <Fragment>
                    <InspectorControls>
                        <PanelBody title={__('Settings')}>
                            <RangeControl
                                value={itemToFetch}
                                min={1}
                                max={100}
                                onChange={(item) => { setAttributes({ itemToFetch: parseInt(item) }); }}
                            />
                        </PanelBody>
                    </InspectorControls>
                    <ServerSideRender
                        block="pl/profile-list"
                        attributes={{ itemToFetch: itemToFetch }}
                    />
                </Fragment>
            );
        }
    }

    const allAttr = {
        itemToFetch: {
            type: 'number',
            default: 5
        },
    };

    registerBlockType('pl/profile-list', {
        title: __('Profile List'),
        icon: 'admin-users',
        keywords: [__('Profile'), __('List')],
        attributes: allAttr,
        category: 'common',
        edit: ProfileList,
        save() {
            return null;
        },
    });

})(wp.i18n, wp.blocks, wp.element, wp.editor, wp.components);