=== Profile ===
Contributors: bharatkambariya
Tags: profile, listing, shortcode
Requires at least: 4.0
Tested up to: 6.2
Stable tag: 1.0.0
License: GPL2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Profile listing page with search and sorting functionality on the front side of a WordPress website.

== Installation ==
* Upload the folder "profile" to wp-content/plugins (or upload a zip through the WordPress admin)

== Frequently Asked Questions ==
= How to select profile block ? =

* Select Profile List block from blocks list.
* Also you can place shortcode [profile]

== Changelog ==
= 1.0.0 =
* Very first release which allows profile sorting functionality like Skills, Educations, Age, No Of Job Completed, Years Of Expriance, etc.