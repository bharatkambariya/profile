<?php
/**
 * Profile Public Class
 */
class Profile_Public {
    /**
     *  nitialize the class and set its properties.
     */
	public function __construct() {
		$this->define_public_hooks();
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {
		add_shortcode( 'profile', array( $this, 'profile_callback' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
		add_action( 'wp_ajax_profile_ajax_function', array( $this, 'profile_ajax_function' ) );
		add_action( 'wp_ajax_nopriv_profile_ajax_function', array( $this, 'profile_ajax_function' ) );
		add_filter( 'template_include', array( $this, 'custom_single_post_template' ), 99 );
        add_action( 'init', array( $this, 'profile_register_blocks' ) );
        add_action( 'enqueue_block_editor_assets', array( $this, 'profile_block_editor_assets' ) );
    }

	/**
	 * Ajax function for profile
	 *
	 * @since    1.0.0
	 */
	public function profile_ajax_function() {
		$formData = isset( $_POST['formData'] ) ? sanitize_text_field( $_POST['formData'] ) : "";
		parse_str( $formData, $formDataArray );
		
		if ( isset( $formDataArray['my_form_nonce'] ) && wp_verify_nonce( $formDataArray['my_form_nonce'], 'my_form_action' ) ) {

			$profile_skill      = isset( $_POST['skills'] ) ? filter_var_array( $_POST['skills'], FILTER_SANITIZE_STRING ) : array();
			$profile_education  = isset( $_POST['education'] ) ? filter_var_array( $_POST['education'], FILTER_SANITIZE_STRING ) : array();
			$keyword_search     = isset( $formDataArray['pf_keyword'] ) ? sanitize_text_field( $formDataArray['pf_keyword'] ) : '';
			$min_age            = isset( $formDataArray['min_age'] ) ? (int) sanitize_text_field( $formDataArray['min_age'] ) : 1;
			$max_age            = isset( $formDataArray['max_age'] ) ? (int) sanitize_text_field( $formDataArray['max_age'] ) : 100;
			$profile_noofjob    = isset( $formDataArray['pf_noofjob'] ) ? sanitize_text_field( $formDataArray['pf_noofjob'] ) : '';
			$profile_yearofexpr = isset( $formDataArray['pf_yearofexpr'] ) ? sanitize_text_field( $formDataArray['pf_yearofexpr'] ) : '';
			$profile_ratings    = isset( $formDataArray['pf_ratings'] ) ? (int) sanitize_text_field( $formDataArray['pf_ratings'] ) : '';
			$post_limit         = isset( $formDataArray['post_limits'] ) ? sanitize_text_field( $formDataArray['post_limits'] ) : 5;
			$shorting           = isset( $formDataArray['shorting'] ) ? sanitize_text_field( $formDataArray['shorting'] ) : 'ASC';
			$paged              = isset( $formDataArray['page_number'] ) ? sanitize_text_field( $formDataArray['page_number'] ) : 1;
			$taxonomy_args      = array();
			$meta_query_args    = array();

			$args = array(
				'post_type'      => 'profile',
				'posts_per_page' => $post_limit,
				'paged'          => $paged,
				'order'          => $shorting,
				'orderby'        => 'title',
				'status'         => 'publish',
			);

			if ( ! empty( $keyword_search ) ) {
				$args['s'] = $keyword_search;
			}

			if ( isset( $profile_skill ) && is_array( $profile_skill ) && count( $profile_skill ) > 0 ) {
				$taxonomy_args[] = array(
					'taxonomy' => 'skill',
					'field'    => 'slug',
					'terms'    => $profile_skill,
				);
			}

			if ( isset( $profile_education ) && is_array( $profile_education ) && count( $profile_education ) > 0 ) {
				$taxonomy_args[] = array(
					'taxonomy' => 'education',
					'field'    => 'slug',
					'terms'    => $profile_education,
				);
			}

			if ( $min_age > 1 || $max_age < 100 ) {
				$time     = strtotime( "-$min_age year", time() );
				$min_date = gmdate( 'Y-m-d', $time );
				$time     = strtotime( "-$max_age year", time() );
				$max_date = gmdate( 'Y-m-d', $time );

				$meta_query_args[] = array(
					'key'     => 'pf_dob',
					'value'   => array( $max_date, $min_date ),
					'type'    => 'DATE',
					'compare' => 'BETWEEN',
				);
			}
			if ( ! empty( $profile_ratings ) ) {
				$meta_query_args[] = array(
					'key'   => 'pf_ratings',
					'value' => $profile_ratings,
				);
			}
			if ( ! empty( $profile_noofjob ) ) {
				$meta_query_args[] = array(
					'key'   => 'pf_jobs_completed',
					'value' => $profile_noofjob,
				);
			}
			if ( ! empty( $profile_yearofexpr ) ) {
				$meta_query_args[] = array(
					'key'   => 'pf_experience',
					'value' => $profile_yearofexpr,
				);
			}
			if ( count( $taxonomy_args ) > 0 ) {
				$args['tax_query'] = $taxonomy_args;
			}

			if ( count( $meta_query_args ) > 0 ) {
				$args['meta_query'] = $meta_query_args;
			}

			$query    = new WP_Query( $args );
			$no_count = $post_limit * ( $paged - 1 ) + 1;
			if ( $query->have_posts() ) :

				ob_start();

				while ( $query->have_posts() ) :
					$query->the_post();
					
					$profile_id = get_the_ID();
					$pf_dob     = get_post_meta( $profile_id, 'pf_dob', true );
					$pf_age     = date_diff( date_create( $pf_dob ), date_create( 'today' ) )->y;
					?>
					<tr>
						<td><?php echo esc_html( $no_count ); ?></td>
						<td><a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a></td>
						<td><?php echo esc_html( $pf_age ); ?></td>
						<td><?php echo esc_html( get_post_meta( $profile_id, 'pf_experience', true ) ); ?></td>
						<td><?php echo esc_html( get_post_meta( $profile_id, 'pf_jobs_completed', true ) ); ?></td>
						<td>
							<?php
							$rating_no    = esc_html( get_post_meta( $profile_id, 'pf_ratings', true ) );
							$total_rating = 5;
							for ( $i = 1; $i <= $total_rating; $i++ ) {
								$star_class = $i <= $rating_no ? 'fa fa-star active' : 'fa fa-star';
								?>
								<span class="<?php echo esc_attr( $star_class ); ?>"></span>
								<?php
							}
							?>
						</td>
					</tr>
					<?php
					$no_count ++;
				endwhile;
				$profile_tr = ob_get_clean();

				$big        = 999999999; // need an unlikely integer
				$pagination = paginate_links(
					array(
						'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
						'format'  => '?paged=%#%',
						'current' => max( 1, $paged ),
						'total'   => $query->max_num_pages,
					)
				);
				wp_reset_postdata();
			else :
				ob_start();
				?>
				<tr>
					<td colspan="6">
						<p>No results found.</p>
					</td>
				</tr>
				<?php
				$profile_tr = ob_get_clean();
			endif;
			$final_html = array(
				'profile_data' => $profile_tr,
				'pagination'   => $pagination,
			);
			wp_send_json_success( $final_html );
		} else {
			$final_html = array(
				'profile_data' => '',
				'pagination'   => '',
				'error' => 'nonce verification failed, handle the error',
			);
			wp_send_json_success( $final_html );
		}
	}

	/**
	 * Override the single post template
	 *
	 * @param $template
	 * @return mixed|string
	 */
	function custom_single_post_template( $template ) {
		global $post;
		if ( $post->post_type === 'profile' ) {
			$template = plugin_dir_path( __FILE__ ) . 'single-profile.php';
		}
		return $template;

	}
	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {
		wp_enqueue_style( 'profile', plugin_dir_url( __DIR__ ) . 'assets/css/profile-public.css', array(), '1.0.0', 'all' );
		wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), '1.0.0', 'all' );
		wp_enqueue_script( 'profile', plugin_dir_url( __DIR__ ) . 'assets/js/profile-public.js', array( 'jquery' ), '1.0.0', true );
		wp_localize_script( 'profile', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
		wp_enqueue_style( 'select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', array(), '1.0.0', 'all' );
		wp_enqueue_script( 'select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', array( 'jquery' ), '1.0.0', true );
		wp_enqueue_script( 'jquery-ui-slider' );
		wp_enqueue_style( 'jquery-ui', plugin_dir_url( __DIR__ ) . 'assets/css/library/jquery-ui.css', array(), '1.0.0', 'all' );

	}

	/**
	 * Shortcode for profile
	 *
	 * @param $atts
	 * @return false|string
	 */
	public function profile_callback( $atts ) {
        $post_limit = isset( $atts['itemToFetch'] ) && $atts['itemToFetch'] > 0 ? $atts['itemToFetch'] : 5;

		ob_start();
		?>
		<section class="profile-main">
			<section>
				<div class="wrap">
					<div class="detail-form">
						<form name="profile-form" class="pf-search-form" id="pf-search-form">
							<?php wp_nonce_field( 'my_form_action', 'my_form_nonce' ); ?>
							<div class="form-content">
								<div class="skills">
									<label for="keyword">Keyword</label>
									<input type="text" name="pf_keyword" id="txtInput" placeholder="">
								</div>
								<div class="inner-data">
									<div class="skills">
										<label for="skills">skills</label>
										<select class="skills-multiple form-control pf-skill" name="pf_skills[]" multiple="multiple">
											<?php
											$skill_terms = get_terms(
												array(
													'taxonomy'   => 'skill',
													'order'      => 'ASC',
												)
											);
											if ( ! empty( $skill_terms ) && ! is_wp_error( $skill_terms ) ) {
												foreach ( $skill_terms as $skill_term ) { ?>
													<option value=" <?php echo esc_attr( $skill_term->slug ); ?>"> <?php echo esc_html( ucwords( $skill_term->name ) ); ?></option>
												<?php }
											}
											?>
										</select>
									</div>
									<div class="skills">
										<label for="Education">Education</label>
										<select class="education-multiple form-control pf-education" name="pf_education[]" multiple="multiple">
											<?php
											$education_terms = get_terms(
												array(
													'taxonomy'   => 'education',
													'order'      => 'ASC',
												)
											);
											if ( ! empty( $education_terms ) && ! is_wp_error( $education_terms ) ) {
												foreach ( $education_terms as $education_term ) { ?>
													<option value="<?php echo esc_attr( $education_term->slug ); ?> "><?php echo esc_html( ucwords( $education_term->name ) ); ?></option>
												<?php }
											}
											?>
										</select>
									</div>
								</div>
								<div class="inner-data">
									<div class="skills">
										<label for="amount">Age:</label>
										<input type="text" id="amount" readonly style="border:0; color:#f6931f; font-weight:bold;">
										<div id="slider-range"></div>
										<input type="hidden" name="min_age" id="min-value" value="1">
										<input type="hidden" name="max_age" id="max-value" value="100">
									</div>
									<div class="skills ratings">
										<label for="age">Ratings</label>
										<div class="stars">
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
										</div>
                                        <label class="clear-rating">Clear</label>
										<input type="hidden" name="pf_ratings" value="" class="pf-ratings" id="pf-ratings">
									</div>
								</div>
								<div class="inner-data">
									<div class="skills">
										<label for="keyword">No of jobs completed</label>
										<input type="text" name="pf_noofjob" id="txtInput" placeholder="">
									</div>
									<div class="skills">
										<label for="keyword">Years of experience</label>
										<input type="text" name="pf_yearofexpr" id="txtInput" placeholder="">
									</div>
								</div>
								<div class="btn">
									<input type="submit" name="search" id="pf_search" class="pf_search form-btn" value="SEARCH">
								</div>
							</div>
							<input type="hidden" name="post_limits" value="5">
							<input type="hidden" name="shorting" class="shorting asc" value="asc">
							<input type="hidden" name="page_number" class="current-page" value="1">

						</form>
					</div>
				</div>
			</section>
			<section class="wrap">
				<div class="detail-form">
					<div class="data-table">
						<table>
							<tr>
								<th>No.</th>
								<th class="headerSortdown asc">Profile Name</th>
								<th>Age</th>
								<th>Years of experience</th>
								<th>No of jobs completed</th>
								<th>Ratings</th>
							</tr>
							<?php
							$paged         = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
							$profile_args  = array(
								'post_type'      => 'profile',
								'posts_per_page' => $post_limit,
								'paged'          => $paged,
								'order'          => 'ASC',
								'orderby'        => 'title',
							);
							$profile_query = new WP_Query( $profile_args );
							if ( $profile_query->have_posts() ) {
								$pf_no = 1;
								while ( $profile_query->have_posts() ) {
									$profile_query->the_post();
									$pf_id  = get_the_ID();
									$pf_dob = get_post_meta( $pf_id, 'pf_dob', true );
									$pf_age = date_diff( date_create( $pf_dob ), date_create( 'today' ) )->y;
									?>
									<tr>
										<td><?php echo esc_html( $pf_no ); ?></td>
										<td><a href="<?php the_permalink(); ?>"> <?php echo the_title(); ?></a></td>
										<td><?php echo esc_html( $pf_age ); ?></td>
										<td><?php echo esc_html( get_post_meta( $pf_id, 'pf_experience', true ) ); ?></td>
										<td><?php echo esc_html( get_post_meta( $pf_id, 'pf_jobs_completed', true ) ); ?></td>
										<td>
											<?php
											$rating_no    = get_post_meta( $pf_id, 'pf_ratings', true );
											$total_rating = 5;
											for ( $i = 1; $i <= $total_rating; $i++ ) {
												$star_class = $i <= $rating_no ? 'fa fa-star active' : 'fa fa-star';
												?>
												<span class="<?php echo esc_attr( $star_class ); ?>"></span>
												<?php
											}
											?>
										</td>
									</tr>
									<?php
									$pf_no++;
								}
								wp_reset_postdata();
							}
							?>
						</table>
					</div>
				</div>
				<div class="pf-pagination">
					<?php
					$big = 999999999; // need an unlikely integer
					echo paginate_links(
						array(
							'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
							'format'  => '?paged=%#%',
							'current' => max( 1, get_query_var( 'paged' ) ),
							'total'   => $profile_query->max_num_pages,
						)
					);
					?>
				</div>
			</section>
		</section>
		<?php
		$pf_main_content = ob_get_clean();
		return $pf_main_content;
	}
    /**
     * Register dynamic blocks.
     *
     * @since 1.0.0
     */
    public function profile_register_blocks() {
        register_block_type( 'pl/profile-list', array(
                'attributes' => array(
                    'itemToFetch'  => array(
                        'type'    => 'number',
                        'default' => 5,
                    )
                ),
                'render_callback' => array( $this, 'profile_callback' ),
            )
        );
    }

    /**
     * Add block editor script
     */
    public function profile_block_editor_assets() {

        wp_enqueue_script( 'profile-gutenberg-block',
            plugin_dir_url( __DIR__ ) . 'assets/blocks/block.build.js',
            array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-components' ),
            '1.0'
        );
    }
}
