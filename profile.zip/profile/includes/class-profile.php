<?php
/**
 * Profile class.
 */
class Profile {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->define_admin_hooks();
	}
	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );
		add_action( 'init', array( $this, 'register_post_type' ) );
		add_action( 'init', array( $this, 'register_taxonomies' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post', array( $this, 'save_meta_data' ) );
	}
	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {
		wp_enqueue_style( 'profile', plugin_dir_url( __DIR__ ) . 'assets/css/profile-admin.css', array(), '1.0.0', 'all' );
		wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), '1.0.0', 'all' );
	}
	/**
	 * Register Custome Post Type
	 *
	 * @since    1.0.0
	 */
	public function register_post_type() {
		$labels = array(
			'name'               => __( 'Profiles', 'manage-all-features' ),
			'singular_name'      => __( 'Profile', 'manage-all-features' ),
			'menu_name'          => __( 'Profiles', 'manage-all-features' ),
			'all_items'          => __( 'All Profiles', 'manage-all-features' ),
			'add_new'            => __( 'Add New', 'manage-all-features' ),
			'add_new_item'       => __( 'Add New Profile', 'manage-all-features' ),
			'edit_item'          => __( 'Edit Profile', 'manage-all-features' ),
			'new_item'           => __( 'New Profile', 'manage-all-features' ),
			'view_item'          => __( 'View Profile', 'manage-all-features' ),
			'search_items'       => __( 'Search Profiles', 'manage-all-features' ),
			'not_found'          => __( 'No profiles found', 'manage-all-features' ),
			'not_found_in_trash' => __( 'No profiles found in trash', 'manage-all-features' ),
		);
		$args   = array(
			'labels'       => $labels,
			'public'       => true,
			'show_in_rest' => true,
			'has_archive'  => true,
			'supports'     => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
		);
		register_post_type( 'profile', $args );
	}

	/**
	 * Register the Skills and Education taxonomies
	 *
	 * @since    1.0.0
	 */
	public function register_taxonomies() {
		$labels = array(
			'name'              => __( 'Skills' ),
			'singular_name'     => __( 'Skill' ),
			'search_items'      => __( 'Search Skills' ),
			'all_items'         => __( 'All Skills' ),
			'parent_item'       => __( 'Parent Skill' ),
			'parent_item_colon' => __( 'Parent Skill:' ),
			'edit_item'         => __( 'Edit Skill' ),
			'update_item'       => __( 'Update Skill' ),
			'add_new_item'      => __( 'Add New Skill' ),
			'new_item_name'     => __( 'New Skill Name' ),
			'menu_name'         => __( 'Skills' ),
		);
		$args   = array(
			'labels'            => $labels,
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'public'            => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'skill' ),
		);
		register_taxonomy( 'skill', array( 'profile' ), $args );

		$labels = array(
			'name'              => __( 'Education' ),
			'singular_name'     => __( 'Education' ),
			'search_items'      => __( 'Search Education' ),
			'all_items'         => __( 'All Education' ),
			'parent_item'       => __( 'Parent Education' ),
			'parent_item_colon' => __( 'Parent Education:' ),
			'edit_item'         => __( 'Edit Education' ),
			'update_item'       => __( 'Update Education' ),
			'add_new_item'      => __( 'Add New Education' ),
			'new_item_name'     => __( 'New Education Name' ),
			'menu_name'         => __( 'Education' ),
		);
		$args   = array(
			'labels'            => $labels,
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'public'            => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'education' ),
		);
		register_taxonomy( 'education', array( 'profile' ), $args );

	}

	/**
	 * Register MetaBox
	 *
	 * @since    1.0.0
	 */
	public function add_meta_boxes() {
		add_meta_box( 'my_custom_metabox_dob', 'Profile Details:', array( $this, 'render_metabox_details' ), 'profile', 'normal', 'default' );
	}

	/**
	 * Render Callback function for profile
	 *
	 * @param object $post current post object.
	 * @since    1.0.0
	 */
	public function render_metabox_details( $post ) {
		$pf_dob          = get_post_meta( $post->ID, 'pf_dob', true );
		$pf_hobbies      = get_post_meta( $post->ID, 'pf_hobbies', true );
		$pf_interest     = get_post_meta( $post->ID, 'pf_interests', true );
		$pf_yearexpr     = get_post_meta( $post->ID, 'pf_experience', true );
		$pf_ratings      = get_post_meta( $post->ID, 'pf_ratings', true );
		$pf_jobcompleted = get_post_meta( $post->ID, 'pf_jobs_completed', true );
		?>
	<div class="profile-detail-wrap">
		<label for="pf_dob">Date of Birth:</label>
		<input type="date" id="pf_dob" name="pf_dob" value="<?php echo esc_attr( $pf_dob ); ?>" /></br>
		<label for="pf_hobbies">Hobbies:</label>
		<input type="text" name="pf_hobbies" value="<?php echo esc_attr( $pf_hobbies ); ?>"></br>
		<label for="pf_interests">Interests:</label>
		<input type="text" name="pf_interests" value="<?php echo esc_attr( $pf_interest ); ?>"></br>
		<label for="pf_experience">Years of Experience:</label>
		<input type="text" name="pf_experience" value="<?php echo esc_attr( $pf_yearexpr ); ?>"></br>
		<label for="pf_ratings">Ratings:</label>
		<input type="radio" name="pf_ratings" value="1" <?php echo esc_attr( $pf_ratings ) == 1 ? 'checked' : ''; ?> >1
		<input type="radio" name="pf_ratings" value="2" <?php echo esc_attr( $pf_ratings ) == 2 ? 'checked' : ''; ?> >2
		<input type="radio" name="pf_ratings" value="3" <?php echo esc_attr( $pf_ratings ) == 3 ? 'checked' : ''; ?> >3
		<input type="radio" name="pf_ratings" value="4" <?php echo esc_attr( $pf_ratings ) == 4 ? 'checked' : ''; ?> >4
		<input type="radio" name="pf_ratings" value="5" <?php echo esc_attr( $pf_ratings ) == 5 ? 'checked' : ''; ?> >5</br>
		<label for="pf_ratings">No. of Jobs Completed:</label>
		<input type="number" name="pf_jobs_completed" value="<?php echo esc_attr( $pf_jobcompleted ); ?>">
	</div>
		<?php
	}

	/**
	 * Save profile details meta.
	 *
	 * @param int $post_id current post id.
	 * @since    1.0.0
	 */
	public function save_meta_data( $post_id ) {

		$dateofbirth = filter_input( INPUT_POST, 'pf_dob', FILTER_SANITIZE_STRING );
		$hobbies     = filter_input( INPUT_POST, 'pf_hobbies', FILTER_SANITIZE_STRING );
		$interest    = filter_input( INPUT_POST, 'pf_interests', FILTER_SANITIZE_STRING );
		$yearofexpr  = filter_input( INPUT_POST, 'pf_experience', FILTER_SANITIZE_NUMBER_INT );
		$ratings     = filter_input( INPUT_POST, 'pf_ratings', FILTER_SANITIZE_NUMBER_INT );
		$jobcomleted = filter_input( INPUT_POST, 'pf_jobs_completed', FILTER_SANITIZE_NUMBER_INT );

		if ( isset( $dateofbirth ) ) {
			update_post_meta( $post_id, 'pf_dob', $dateofbirth );
		}
		if ( isset( $hobbies ) ) {
			update_post_meta( $post_id, 'pf_hobbies', $hobbies );
		}
		if ( isset( $interest ) ) {
			update_post_meta( $post_id, 'pf_interests', $interest );
		}
		if ( isset( $yearofexpr ) ) {
			update_post_meta( $post_id, 'pf_experience', $yearofexpr );
		}
		if ( isset( $ratings ) ) {
			update_post_meta( $post_id, 'pf_ratings', $ratings );
		}
		if ( isset( $jobcomleted ) ) {
			update_post_meta( $post_id, 'pf_jobs_completed', $jobcomleted );
		}
	}
}
