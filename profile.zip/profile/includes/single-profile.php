<?php
get_header();

$profile_id    = get_the_ID();
$pf_dob        = get_post_meta( $profile_id , 'pf_dob', true );
$pf_hobbies    = get_post_meta( $profile_id , 'pf_hobbies', true );
$pf_interest   = get_post_meta( $profile_id , 'pf_interests', true );
$rating_no     = get_post_meta( get_the_ID(), 'pf_ratings', true );
$experience    = get_post_meta( $profile_id , 'pf_experience', true );
$job_completed = get_post_meta( $profile_id , 'pf_jobs_completed', true )
?>
<article id="post-<?php the_ID(); ?>">
	<header class="entry-header alignwide">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
	</header><!-- .entry-header -->
	<div class="entry-content">
	   <div class="main-wrap">
			<div class="profile--content">
				<?php the_content(); ?>
			</div>
			<div class="profile--details">
				<?php
				if ( ! empty( $experience ) ) {
					?>
					<span>Years of experience: <?php echo esc_attr( $experience ); ?></span></br>
					<?php
				}
				if ( ! empty( $job_completed ) ) {
					?>
					<span>No of jobs completed: <?php echo esc_attr( $job_completed ); ?></span></br>
					<?php
				}
				if ( ! empty( $pf_dob ) ) {
					$pf_age = date_diff( date_create( $pf_dob ), date_create( 'today' ) )->y;
					?>
					<span>Age : <?php echo esc_attr( $pf_age ); ?></span></br>
					<?php
				}
				if ( ! empty( $rating_no ) ) {
					?>
					<span>Ratings:
					<?php
					$total_rating = 5;
					for ( $i = 1; $i <= $total_rating; $i++ ) {
						$star_class = $i <= $rating_no ? 'fa fa-star active' : 'fa fa-star';
						?>
						<span class="<?php echo esc_attr( $star_class ); ?>"></span>
						<?php
					}
					?>
					</span></br>
					<?php
				}
				if ( ! empty( $pf_hobbies ) ) {
					?>
					<span>Hobbies: <?php echo esc_attr( $pf_hobbies ); ?></span></br>
					<?php
				}
				if ( ! empty( $pf_interest ) ) {
					?>
					<span>Interests: <?php echo esc_attr( $pf_interest ); ?></span>
					<?php
				}
				?>
			</div>
		</div>
	</div><!-- .entry-content -->
</article>
<?php
get_footer();
