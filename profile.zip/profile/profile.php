<?php
/**
 * Plugin Name: Profile
 * Plugin URI: https://profiles.wordpress.org/bharatkambariya/
 * Description: To create a profile listing page with search and sorting functionality
 * Version: 1.0
 * Author: Bharat Kambariya
 * Author URI: https://profiles.wordpress.org/bharatkambariya/
 * Profile
 *
 * @package Profile
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'PROFILE', '1.0.0' );
define( 'PROFILE_DIR', plugin_dir_path( __FILE__ ) );
define( 'PROFILE_URL', plugin_dir_url( __FILE__ ) );


// Include the main plugin class.
require_once PROFILE_DIR . 'includes/class-profile.php';

// Include the main public class.
require_once PROFILE_DIR . 'includes/class-profile-public.php';


// Instantiate the main plugin class.
$profile = new Profile();

// Instantiate the main public class.
$profile_public = new Profile_Public();
